# Add or remove vhosts to a running/stop Nginx instance.

## Use

`const nginx = require('nginx-plugin')(settings);`

## settings

> example: `{ sudo:true, id: 'restapi',template:{ path: 'resapi-nginx-conf.tmpl', dirname: __dirname + '/develop-server/' }}`


- `sudo`  - true/false or undefined(:default)

- `id` - string ID for you project ( default: 'nginx-plugin' )

- `template` - as string, path you config vhost server file ( default: 'default' )

- `template` - as object, config options for you config vhost server file ( default: 'default' )
  
  - `template.path` - path for you config vhost server file ( default: 'default' )
  - `template. ` - more oprtion for you config server file

- `conf.tmpl` - you cofig for you config server file [https://handlebarsjs.com/](Handlebars) template

## Return

`nginx.logHttp` - path log file nginx
`nginx.logError` - path log file nginx
`nginx.pidPath` - path pid file nginx
`nginx.confPath` - path dir vhosts config nginx
`nginx.pid` - pid process after start vhost server
`nginx.confVhost` - path config file after start vhost server


## Methods

`nginx.startVhost` - return promise, start you config vhost server

> example: `nginx.startVhost.then(result=>...,error=>...)`

`nginx.stopVhost` - return promise, stop you config vhost server

> example: `nginx.stopVhost.then(result=>...,error=>...)`

`nginx.killVhost` - force stop you config vhost server

> example: `nginx.killVhost(path, pid, sudo)`

## Example of use for webpack

```
module.exports = {
    devServer: {
        before: function(app){
            const nginx = process.argv.includes('--nginx') && require('nginx-plugin')({
                sudo:true, id: 'restapi',
                template:{ path: 'resapi-nginx-conf.tmpl', dirname: __dirname + '/develop/application-restapi/' }
            });
            nginx && nginx.startVhost.then(
                result=> console.log('\n[\x1b[5m\x1b[36mWARN\x1b[0m]', 'rest API is working\n')
                    || ['SIGINT', 'SIGTERM','extt'].forEach((sig) =>process.on(sig,()=>nginx.killVhost(nginx.confVhost,nginx.pid,nginx.sudo))))
        }
    },
    .....
}

```
