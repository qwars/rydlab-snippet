'use strict';

const command = require('child_process'), handlebars = require('handlebars'), fs = require('fs'), fsSudo = require('@mh-cbon/sudo-fs'),
      nginx = new Promise(function(resolve,reject){
          command.exec('which nginx',{encoding:'utf8'},function(error,stdout,stderr){
              error && reject()
              stdout && command.exec('nginx -V',{encoding:'utf8'},function(error,stdout,stderr){
                  error && reject();
                  stderr && resolve({
                      logHttp: stderr.match(/--http-log-path=(.+?)\s+/g)[0].split(/=/)[1].trim(),
                      logError: stderr.match(/--error-log-path=(.+?)\s+/g)[0].split(/=/)[1].trim(),
                      pidPath: stderr.match(/--pid-path=(.+?)\s+/g)[0].split(/=/)[1].trim(),
                      confPath: ((path) => [].concat( fs.readFileSync(path).toString().match(/include(.+?)[;]/g) ).filter((p)=>p.includes('site') || p.includes('conf.d') ).reverse()[0].replace(/include\s+/,'').trim().split(/\//).reverse().slice(1).reverse().join('/') )(stderr.match(/--conf-path=(.+?)\s+/g)[0].split(/=/)[1].trim())
                  })            
              })
          })
      })


class NginxState {
    constructor(options) {
        options.id || Object.assign(options,{id: module.id.split(/\//).reverse()[1] })
        options.template || Object.defineProperty(options, 'template', {value: 'default',writable:true,enumerable:true});        
        typeof options.template == 'string' && Object.assign( options, { template: { path: options.template } } );
        fs.existsSync('./templates/' + options.template.path + '-nginx-conf.tmpl') && Object.assign(options,{template:{ path:'./templates/' + options.template.path + '-nginx-conf.tmpl' }})
        options.template.cname || Object.assign(options.template,{cname: options.id})
        options.template.port || Object.assign(options.template,{port: '8080'})
        Object.defineProperty(this, 'content', {
            value: handlebars.compile(String(fs.readFileSync(options.template.path)))(options.template)
        });
        options.sudo || Object.defineProperty(options,'sudo',{value: ''});
        options.sudo && typeof options.sudo == 'boolean' && Object.assign(options,{sudo: 'sudo '});
        Object.assign(this,options)
    }
    get startVhost(){
        return new Promise((resolve,reject)=>nginx.then(
            result=>!Object.assign(this,result) || !fs.existsSync(result.pidPath) || fs.readFileSync(result.pidPath, 'utf8').trim(),
            error=>console.warn('[\x1b[5m\x1b[33mWARN\x1b[0m]', 'Nginx not found')
        ).then(
            result =>Object.assign(this,{pid: typeof result != 'boolean' && result})
                && Object.assign(this,{confVhost: this.confPath + '/npm-'+ this.pid +'-server-dev-' + this.id + '-nginx-plugin.conf'})
                && command.execSync(this.sudo + ' echo ') && this.sudo ? fsSudo.writeFile : fs.writeFile,
            error =>null
        ).then(
            write =>write(this.confVhost, this.content, 'utf-8',
                          (err, data)=>err ? reject(err)
                          : command.exec(this.sudo + ' nginx' + (this.pid ? ' -s reload' : ''),
                                         (err,stdout,stderr) => err||stderr ? reject(err||stderr) : resolve(stdout)) ),
            error =>null
        ))
    }    
    get stopVhost(){
        let vhost = new Object();
        return new Promise((resolve,reject)=>{
            nginx.then(
                result=>!Object.assign(vhost,result) || !fs.existsSync(result.pidPath) || fs.readFileSync(result.pidPath, 'utf8').trim(),
                error=>console.warn('[\x1b[5m\x1b[33mWARN\x1b[0m]', 'Nginx not found')
            ).then(
                result=>Object.assign(vhost,{pid: typeof result != 'boolean' && result}) && command.execSync(this.sudo + ' echo ') && this.sudo ? fsSudo.unlink : fs.unlink,
                error=>console.warn('[\x1b[5m\x1b[33mWARN\x1b[0m]', 'Nginx not found')
            ).then(
                unlink =>fs.readdir(vhost.confPath,(err,files)=>err?reject(err):vhost.pid?command.exec(this.sudo + ' nginx -s ' + (files.filter((f)=>f.includes('-server-dev-' + this.id + '-nginx-plugin.conf')).filter((f)=>unlink([vhost.confPath,f].join('/'))||f.includes(vhost.pid + '-server-dev-' + this.id + '-nginx-plugin.conf'))[0] ?'reload':'quit'),(err,stdout,stderr) => err||stderr ? reject(err||stderr) : resolve(stdout)):resolve(files.filter((f)=>f.includes('-server-dev-' + this.id + '-nginx-plugin.conf')).forEach((f)=>unlink([vhost.confPath,f].join('/'))))
                ),
                error =>null
            )
        })
    }
    killVhost(path, pid, sudo){
        return ((unlink)=>unlink(path)||command.execSync((typeof sudo == 'boolean' && sudo ? 'sudo ' : sudo || '') + ' nginx -s ' + (pid ? 'reload' : 'quit')))(sudo?fsSudo.unlink:fs.unlink)
    }
}
module.exports = (config) => new NginxState(config)
